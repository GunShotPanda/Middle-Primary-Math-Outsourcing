/**
 * 每个切片特有的js
 * 初中数学
 */

//通用文件
var cfiles = [
			'js/jquery.min.js',
			'css/middle_math.css',
            'js/middle_math.js',
            'js/easeljs-0.8.1.min.js',
            'js/tweenjs-0.6.1.min.js',
            'js/movieclip-0.8.1.min.js',
            'js/preloadjs-0.6.1.min.js',
            'js/animaCreateJs.js',
            'js/question.js'
            ];
//私有文件             
var pfiles = [
	'css/index.css',
	'js/createjsInit.js',
    'js/question.js',
    //'js/hitEgg.js'
           ];

var loader = new loader_common();
loader.addCommonFiles(cfiles);
loader.addPrivateFiles(pfiles);
loader.load();

