/*
 * 智力大比拼
 */
function numberOut(){
	var num = parseInt(Math.random()*20+1);
	document.getElementById("question").innerText = num;
}
