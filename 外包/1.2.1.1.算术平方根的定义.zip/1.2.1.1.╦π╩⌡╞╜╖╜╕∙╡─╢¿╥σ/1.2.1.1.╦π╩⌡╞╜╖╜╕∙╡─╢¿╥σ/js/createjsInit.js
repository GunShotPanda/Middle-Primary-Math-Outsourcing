$(document).ready(function(){
	//初始化智力大比拼游戏
	function init(){
		new animaCreateJs([
			{ canvasId:"canvas1", name:"beategg10mv", lib:beategg10mv, autoPlay:false }
		]);
	}
	init();
});
