function change_1(){
	var text_1=document.getElementsByClassName('text_1')[0];
	if($('.text_1').hasClass("change")){
		$('.text_1').removeClass("change");
		text_1.style.opacity="0";
	}else{
		$('.text_1').addClass("change");
		text_1.style.opacity="1";
	}
}
function change_2(){
	var text_2=document.getElementsByClassName('text_2')[0];
	if($('.text_2').hasClass("change")){
		$('.text_2').removeClass("change");
		text_2.style.opacity="0";
	}else{
		$('.text_2').addClass("change");
		text_2.style.opacity="1";
	}
}
function change_3(){
	var example=document.getElementsByClassName("example")[0];
	if($('.example').hasClass("change")){
		$('.example').removeClass("change");
		example.style.opacity="0";
	}else{
		$('.example').addClass("change");
		example.style.opacity="1";
	}
}
function change_4(){
	var text_3=document.getElementsByClassName('text_3')[0];
	if($('.text_3').hasClass("change")){
		$('.text_3').removeClass("change");
		text_3.style.opacity="0";
	}else{
		$('.text_3').addClass("change");
		text_3.style.opacity="1";
	}
}
