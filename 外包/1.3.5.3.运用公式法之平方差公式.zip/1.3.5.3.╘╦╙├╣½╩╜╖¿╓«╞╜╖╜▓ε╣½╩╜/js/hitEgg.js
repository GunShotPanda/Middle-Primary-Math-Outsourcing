/*
 * 砸蛋
 */

$(document).ready(function(){
	var index = 0;
	$("#startBtn").click(function() {
		console.log( "index:",index );
		if(index>=10) {
			var animaArr = animaCreateJs.prototype.animationArr;
			var animaObj = animaArr[0];
			var anima = animaObj["anima"];
			for(var i=0;i<10;i++) {
				anima["egg"+(i+1)].visible = true;
			}
			index = 0;
		}
	});
	
	$(document).bind("loadComplete",function() {
    	var animaArr = animaCreateJs.prototype.animationArr;
		var animaObj = animaArr[0];
		var anima = animaObj["anima"];
		anima.egg1.addEventListener("click",eggHandler);
		anima.egg2.addEventListener("click",eggHandler);
		anima.egg3.addEventListener("click",eggHandler);
		anima.egg4.addEventListener("click",eggHandler);
		anima.egg5.addEventListener("click",eggHandler);
		anima.egg6.addEventListener("click",eggHandler);
		anima.egg7.addEventListener("click",eggHandler);
		anima.egg8.addEventListener("click",eggHandler);
		anima.egg9.addEventListener("click",eggHandler);
		anima.egg10.addEventListener("click",eggHandler);
		var stage = animaObj["stage"];
		stage.enableMouseOver();
//		anima.egg1.addEventListener("mouseover" ,mousePosHandler);
		
		
	});
	
	/**
	 * 鼠标经过 指针变化 未启用
	 * @param {Object} evt
	 */
	function mousePosHandler(evt) {
		var animaArr = animaCreateJs.prototype.animationArr;
		var animaObj = animaArr[0];
		var anima = animaObj["anima"];
		anima.egg1.s1_btn.gotoAndStop(1);
//		anima.egg1.s1_btn.hitArea = anima.egg1.s1_btn.shake;
		
//		console.log(evt.target.id  );
//		$("#canvas1").css( { cursor: "url(img/hammer.png), progress" });
	}
	
	function eggHandler(evt) {
		var egg = evt.currentTarget;
		var anima = egg.parent;
		var btn = evt.target;
		if(btn.name=="eggBtn") {
			anima.removeChild(egg);
			anima.addChild(egg);
		}
		else {
			egg.visible = false;
			index++;
			egg.eggPop.gotoAndStop(0);
			egg.gotoAndStop(0);
		}
		
	}

	 
	
	
});