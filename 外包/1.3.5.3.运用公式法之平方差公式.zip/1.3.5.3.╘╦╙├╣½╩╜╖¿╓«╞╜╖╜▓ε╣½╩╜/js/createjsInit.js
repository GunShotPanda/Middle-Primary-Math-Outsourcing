$(document).ready(function(){
	//初始化砸蛋游戏
	function init(){
		new animaCreateJs([
			{ canvasId:"canvas1", name:"beategg10mv", lib:beategg10mv, autoPlay:false }
		]);
	}
	init();
});
