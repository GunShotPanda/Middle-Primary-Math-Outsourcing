var text = document.getElementsByClassName('text');
//var text_change=document.getElementsByClassName('text_change');
function change_1() {

    var text_1 = document.getElementsByClassName("text_1");
    if ($('.text_1').hasClass("change_to")) {
        $(".text_1").removeClass("change_to");
        text_1[0].style.opacity = "0";
        
        $('.text_change_1').html('<span class="text_change">(1)非正数：</span>');
		
//      text[0].innerHTML='(1)非正数：<span class="text_1">0和负数</span>'
    }
    else {
    	 $('.text_change_1').html('<span class="text_change">(1)非正  | 数：</span>');

//      text[0].innerHTML='(1)非正 | 数：<span class="text_1">0和负数</span>'
        $(".text_1").addClass("change_to");
        text_1[0].style.opacity = "1";
    }

}
function change_2() {
    var text_2 = document.getElementsByClassName("text_2");


    if ($('.text_2').hasClass("change_to")) {
        $(".text_2").removeClass("change_to");
//      text_change[1].innerHTML='<span class="text_2">0和正数</span>';
		$('.text_change_2').html('<span class="text_change">(2)非负数：</span>');
        text_2[0].style.opacity = "0";
    }
    else {
//      text[1].innerHTML='(2)非负 | 数：<span class="text_2">0和正数</span>';
		$('.text_change_2').html('<span class="text_change">(2)非负 | 数：</span>')
        $(".text_2").addClass("change_to");
        text_2[0].style.opacity = "1";
    }
}
function change_3() {
    var text_3 = document.getElementsByClassName("text_3");


    if ($('.text_3').hasClass("change_to")) {
       $('.text_change_3').html('<span class="text_change_3">(3)非正整数：</span>');
        $(".text_3").removeClass("change_to");
        text_3[0].style.opacity = "0";
    }
    else {
        $('.text_change_3').html('<span class="text_change_3">(3)非正 | 整数：</span>');
        $(".text_3").addClass("change_to");
        text_3[0].style.opacity = "1";
    }
}
function change_4() {
    var text_4 = document.getElementsByClassName("text_4");


    if ($('.text_4').hasClass("change_to")) {
        $('.text_change_4').html('<span class="text_change_4">(4)非负整数：</span>');
        $(".text_4").removeClass("change_to");
        text_4[0].style.opacity = "0";
    }
    else {
         $('.text_change_4').html('<span class="text_change_4">(4)非负 | 整数：</span>');
        $(".text_4").addClass("change_to");
        text_4[0].style.opacity = "1";
    }
}
function change_5() {
    var text_5 = document.getElementsByClassName("text_5");


    if ($('.text_5').hasClass("change_to")) {
		$('.text_change_5').html('<span class="text_change_5">(5)非正有理数：</span>');
        $(".text_5").removeClass("change_to");
        text_5[0].style.opacity = "0";
    }
    else {
        $('.text_change_5').html('<span class="text_change_5">(5)非正 | 有理数：</span>');
        $(".text_5").addClass("change_to");
        text_5[0].style.opacity = "1";
    }
}
function change_6() {
    var text_6 = document.getElementsByClassName("text_6");


    if ($('.text_6').hasClass("change_to")) {
        $('.text_change_6').html('<span class="text_change_6">(6)非负有理数：</span>');
        $(".text_6").removeClass("change_to");
        text_6[0].style.opacity = "0";
    }
    else {
         $('.text_change_6').html('<span class="text_change_6">(6)非负 | 有理数：</span>');
        $(".text_6").addClass("change_to");
        text_6[0].style.opacity = "1";
    }
}