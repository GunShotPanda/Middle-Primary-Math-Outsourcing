/**
 * 每个切片特有的js
 * 初中数学
 */

//通用文件
var cfiles = ['js/jquery.min.js',
             'css/preload.min.css', 
             'css/middle_math.css',
            'js/preloadjs-0.6.1.min.js',
             'js/preload.min.js',
             'js/middle_math.js',
            'js/animaCreateJs.js'
            ];
//私有文件             
var pfiles = [
	'css/index.css',
	'css/first.css'
           ];

var loader = new loader_common();
loader.addCommonFiles(cfiles);
loader.addPrivateFiles(pfiles);
loader.load();

