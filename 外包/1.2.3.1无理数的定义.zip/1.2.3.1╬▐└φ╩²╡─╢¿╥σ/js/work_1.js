function change(){
	var text=document.getElementById('text_btn');
	if($('#text_btn').hasClass("change")){
		$("#text_btn").removeClass("change");
		text.style.opacity="0";
	}
	else{
		$('#text_btn').addClass("change");
		text.style.opacity="1";
	}
}
