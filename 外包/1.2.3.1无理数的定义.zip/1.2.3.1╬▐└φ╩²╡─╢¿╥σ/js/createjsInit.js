$(document).ready(function(){
	init();
	function init(){
		new animaCreateJs([
			{ canvasId:"canvas1", name:"aa_mv", lib:aa_mv, autoPlay:false }
		]);
	}

});
