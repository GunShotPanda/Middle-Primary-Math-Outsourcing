function change_1(){
	var text_1=document.getElementsByClassName("text_1")[0];
	if($('.text_1').hasClass("change")){
		text_1.style.opacity="0";
		$('.text_1').removeClass("change");
	}
	else{
		text_1.style.opacity="1";
		$('.text_1').addClass("change");
		
	}
}
function change_2(){
	var text_2=document.getElementsByClassName("text_2")[0];
	if($('.text_2').hasClass("change")){
		text_2.style.opacity="0";
		$('.text_2').removeClass("change");
	}
	else{
		text_2.style.opacity="1";
		$('.text_2').addClass("change");
		
	}
}
function change_3(){
	var text_3=document.getElementsByClassName("text_3")[0];
	if($('.text_3').hasClass("change")){
		text_3.style.opacity="0";
		$('.text_3').removeClass("change");
	}
	else{
		text_3.style.opacity="1";
		$('.text_3').addClass("change");
		
	}
}
function change_4(){
	var text_4=document.getElementsByClassName("text_4")[0];
	if($('.text_4').hasClass("change")){
		text_4.style.opacity="0";
		$('.text_4').removeClass("change");
	}
	else{
		text_4.style.opacity="1";
		$('.text_4').addClass("change");
		
	}
}