/**
 * 每个切片特有的js
 * 初中数学
 */

//通用文件
var cfiles = [
			'js/jquery.min.js',
			'css/middle_math.css',
            'js/middle_math.js',
            'js/easeljs-0.8.1.min.js',
            'js/tweenjs-0.6.1.min.js',
            'js/movieclip-0.8.1.min.js',
            'js/preloadjs-0.6.1.min.js',
            'js/animaCreateJs.js'
            ];
//私有文件             
var pfiles = [
	'js/beategg10mv.js',
	'js/createjsInit.js',
	'js/jquery-1.11.0.js',
    'js/hitEgg.js',
    'js/draw_canvas.js',
    'js/change.js'
           ];

var loader = new loader_common();
loader.addCommonFiles(cfiles);
loader.addPrivateFiles(pfiles);
loader.load();

