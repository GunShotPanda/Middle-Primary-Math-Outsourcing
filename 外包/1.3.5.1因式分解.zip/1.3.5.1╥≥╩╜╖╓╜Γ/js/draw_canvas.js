var canvas_1=document.getElementById("canvas_text_2");
var canvas_2=document.getElementById("canvas_text_3");

var context_1=canvas_1.getContext("2d");
var context_2=canvas_2.getContext("2d");

context_1.fillStyle="white";



context_1.font="25px   	SimSun";
context_1.fillText("多项式",10,100);


context_1.strokeStyle="white";
context_1.moveTo(90,90);
context_1.lineTo(138,90);
context_1.stroke();
//context_1.font="25px  Microsoft JhengHei";
context_1.fillText("几个整式的积",140,100);
context_1.fillText("化为",90,50);

context_1.moveTo(138,90);
context_1.lineTo(133,85);
context_1.lineTo(133,95);
context_1.lineTo(138,90);
context_1.fill();




context_2.fillStyle="white";
context_2.strokeStyle="white";

context_2.font="25px  SimSun";

context_2.fillText("多项式",10,90);
context_2.fillText("整式乘积",200,90);
context_2.fillText("因式分解",90,65);
context_2.fillText("整式乘法",90,120);

context_2.moveTo(90,80);
context_2.lineTo(195,80);
context_2.lineTo(190,75);
context_2.stroke();
context_2.moveTo(90,90);
context_2.lineTo(195,90);
context_2.moveTo(90,90);
context_2.lineTo(95,95);
context_2.stroke();





