(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 860,
	height: 260,
	fps: 24,
	color: "#000000",
	manifest: []
};



// symbols:



(lib.下拉按下 = function() {
	this.spriteSheet = ss["aa_mv_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.下拉 = function() {
	this.spriteSheet = ss["aa_mv_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.元件14 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF8EF").s().p("AgZAuQgEgDgCgGQgCgGADgFQAEgFAGgBQAFgCAGADQAFADABAGQACAGgDAFQgEAFgFACIgEABQgEAAgEgDgAgGAAQgJgEgDgLQgDgKAGgJQAGgKAJgDQAKgCAJAFQAKAFADALQADALgGAJQgGAIgKADIgHAAQgGAAgGgDg");
	this.shape.setTransform(3.1,4.8,1,1,0,0,0,-0.2,-0.1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,9.9);


(lib.元件10 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BF5026").s().p("AgSASQgHgIAAgKQAAgJAHgJQAJgHAJAAQAKAAAIAHQAIAJAAAJQAAAKgIAIQgIAIgKAAQgJAAgJgIg");
	this.shape.setTransform(2.7,2.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,5.3,5.3);


(lib.元件6 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FC5A5A").s().p("AAAAQQgkgBgagRIgEgDQBFgVBAAVIgFAEQgaARgjAAIgBAAg");
	this.shape.setTransform(8.8,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#5F0606").s().p("AhCAZQgVgRAAgQQAAgTAaAEQAaADAjAAQAlAAAZgDQAagEAAATQAAAQgVARQhAgVhFAVg");
	this.shape_1.setTransform(8.9,2.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,17.7,7.4);


(lib.囧_1_1_33819 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("-", "30px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-10.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.6,-18.6,14.2,37.5);


(lib.kk_55363 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3AB7FF").s().p("ABwB1QA5gzADhjIAAgXIgoAAIAAgVIApAAIAAg4IAWAAIAAA4IBJAAQgCBmgDA/QgDAmghABIglgBIgEgYIAiADQAUAAABgXQAEhEABhGIg0AAIAAAXQgCBqg/A+IgRgSgAniB1QAngRAdgVIAOAQQgkAXghAQQgGgJgHgIgAIFCFIAAgPIjUAAIAAi6IAVAAIAACnIC/AAIAAinIAVAAIAADJgAlzBhIAMgQQAlARAgARIgMASQgjgUgigQgAogB5QATgyANgzQAIAFANAEIgfBlgAjECAIgFgZQAWACATAAQATAAAAgSIAAhmIiDAAIAAgUIEPAAIAAAUIh1AAIAABtQAAAigkAAIgqAAgAkPBhQAfgoAdg1IAUALQgdAyghAsIgSgMgAhTAQIASgMQAiApAfAtIgUANQgigxgdgmgABvBYIheAKIgKgWQAMgHAHgPQAOgbAOgoIguAAIAAgUICEAAIAAAUIg/AAQgXA5gRAgIBDgGQgJgYgKgWIATgIQARAlAPAkIgVAJIgEgKgAlHBRIAAgJIh1AAIAAAJIgTAAIAAhpIBEAAIAAgWIg4AAIAAgRICFAAIAAARIg6AAIAAAWIBFAAIAABpgAl4A3IAxAAIAAgYIgxAAgAm8A3IAxAAIAAgYIgxAAgAl4APIAxAAIAAgWIgxAAgAm8APIAxAAIAAgWIgxAAgAFjBNIAAiWICFAAIAACSIgUAAIAAgNIhdAAIAAARgAGwApIAkAAIAAgoIgkAAgAF3ApIAkAAIAAgoIgkAAgAGwgPIAkAAIAAgoIgkAAgAF3gPIAkAAIAAgoIgkAAgAoogqIAOgQQAbAUAUARIgQASQgXgVgWgSgAk3g7IAAgbIiTAAIAAAbIgUAAIAAgtIBVAAIgOgVIATgJIATAeIBOAAIAAAtgAochyIAOgPQAdAWAQAPIgQARQgVgVgWgSgAAUhaIAAgUIBtAAIAAAUgAj3hfIAAgVIDeAAIAAAVgAEihiIAAgTIEHAAIAAATg");
	this.shape.setTransform(140,105);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,102,153,0.467)").s().p("AmiDXIAAmtINGAAIAAGtg");
	this.shape_1.setTransform(162.7,105.1,1.952,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(84.7,91.4,110.8,27.1);


(lib.kk_52377 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00DEFF").ss(2,1,1).p("ACWAAQAAA9gsAtQgtAsg9AAQg8AAgtgsQgsgtAAg9QAAg8AsgtQAtgsA8AAQA9AAAtAsQAsAtAAA8gAAAAAIg7A8Ag8g8IA8A8AA9g8Ig9A8IA9A9");
	this.shape.setTransform(15,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(21,21,21,0)").s().p("AhoBpQgsgsgBg9QABg9AsgrQArgsA9gBQA9ABAsAsQAtArgBA9QABA9gtAsQgsAtg9gBQg9ABgrgtgAAAAAIA9A9Ig9g9IA9g7Ig9A7gAg7A8IA7g8Ig7g7IA7A7g");
	this.shape_1.setTransform(15,15);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-1,32,32);


(lib.元件51 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("）", "30px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-9.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.6,-18.6,19.2,37.5);


(lib.元件50 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("（", "30px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-9.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.6,-18.6,19.2,37.5);


(lib.元件49 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACZB/QgFgGAAgHQgBgJAGgFQAFgGAHABQAJAAAHAJQAGAGADAAQADAAADgCQAFgDAIgIIAAgbIgBgkIgCg1QgCgQgFgHQgDgFgIAAIgFABIAAgGIAtgNQAFAHADAFQAEALABASQADAiABApQARgVATgfQAHgLgBgJQABgFgIgGIgJgHQgBgDAAgFQAAgHAGgGQAFgGAHABQAIgBAHAHQAFAGAAAIQAAAKgFANQgGANgUAdQgaApgZAdQgQATgKAIQgKAIgKAGQgHACgFAAQgJAAgGgGgAjTBFQgGgFgGgJQgEgKgHgUQgRAWgKAJQgKALgGADQgGACgHAAQgIABgFgFQgEgEAAgHQAAgIAEgFQAGgEAHAAQAEAAAFACQAIAEADgBQADAAAEgBQAFgCAGgIIAQgTQgOgygJgKQgEgHgIAAIgKABIABgFIAzgJQAOAVAGAbQAOgVAHgJQALgMAGgDQAGgEAHABQAIgBAFAFQAEAEAAAIQAAAHgEAFQgFAEgGAAIgLgCIgJgBQgGAAgFAEQgIAGgLATQAMAqAIAKQAEAGAFAAQAEAAACgCQAFgDAIgMIAGACQgNAVgMAJQgJAGgKAAQgJAAgGgDgAAhBFIAAgEQA1g/AMgVQALgWAAgVQAAgQgJgKQgKgKgNAAQgXAAgMAXIgGgCQAJgcAQgOQAPgNAVAAQAQAAAMAHQAMAHAHAMQAIAMgBALQAAAUgKATQgPAbgyAvIArAAQAQAAAFgBQAFgBADgDQADgEAEgKIAGAAIgLA6gAiJgUIAAgTICdAAIAAATg");
	this.shape.setTransform(-0.8,3.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-31.6,-10.1,61.7,26.7);


(lib.元件48 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#C4C4C4").ss(1,1,1).p("AApgqQACACADACAAGgjQAAgBABAAQAFgDAEAAAAQgMQgHACgFAFQgEAEgDAEQgBABAAAAQgEAGgBAGQAAAAAAABQgBADgBAEAgEACQgBgBAAgBQAAAAgBgCQAAgDACgDAgEAEQAAgBAAgBAgtAhQABgBAAgCQACgEAEgDQAEgCAFgCQAFgCAFgBQAFgBAFABAgpALQACgBADgCQAGgEAIgBQAIgCAKABAgmArIABAAIAAAA");
	this.shape.setTransform(-5.2,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxA7IgBAAQgEgBgCgEIgBgEIABgEQACgEAEgDIAJgEIAKgDQAFgBAFABIAAABIgBABIgBAHIABgHIABgBIAAgBQABgGAEgFIABgBQADgHAFgEQAGgEAEgCQgEACgGAEQgFAEgDAHIgBABIgBgDIAAgCIgBgEIABgFIgBAFIABAEIAAACIABADQgEAFgBAGQgFgBgFABIgKADIgJAEQgEADgCAEIgBAEQgEgEAAgDQAAgEACgEQABgEADgCIACgBQgCgHAEgEQAEgFAGgDQAGgCAGgBQAGAAAGABIABgFIAFgLQADgGAEgDQgGgGgDgGQgCgHABgHQgBAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAQABgDADgCQACgEAEgCQAEgDACAAQADgBACADQADAEAAADIABAIQAAAEACAEIAFADIAIADIADACQADgFAEgDQAEgEADABIABABQASAWAAARQABAOgFADQgDADgGgBQgHgCgCAAIgBAAIgNAPQgKALgIAEQgIAEgVAEQgPACgHAAIgGgBgAgiATQgIACgGAEIgFADIAFgDQAGgEAIgCQAIgBAJAAIgEAAIgNABgAgEgTIAAABIAAgBQAEgEAEAAQgEAAgEAEgAAhgWIgEgEIAEAEgAgQAVIAAAAg");
	this.shape_1.setTransform(-4,-1.2);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.8,-7.2,13.1,13.1);


(lib.元件47 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#C4C4C4").ss(1,1,1).p("AgLggQAAgBAAAAQgGgDgFABAgQgIQAGABAGADQAFAEAEADQABABABAAQADAFADAFAAHACQAAABAAABAAsAEQgDgBgCgBQgHgCgIAAQgJAAgIACAAFgIQABADABADQAAACAAAAQAAABAAABAAuAkIAAABIAAgBAAzAZQAAgBgBgCQgCgEgFgCQgEgBgFgBQgGgBgFAAQgFAAgFABQAAABABABQABADABADAgvghQgBACgCAD");
	this.shape.setTransform(5,-1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgBA2QgJgDgMgJIgQgMIAAAAQgDAAgGADQgGACgEgCQgEgCgCgOQgEgRAOgZIACgBQACgBAFADQAEACAEAFIADgDIAGgEIAFgFQABgDAAgFIgBgHQAAgEACgEQACgDADAAQAEAAAEACQAEABADADQABACABADIABABQACAGgBAHQgBAHgDAHQACADAEAFQAFAFADAEIABAFQAGgCAGgBQAGAAAHABQAGACAEAEQAFADAAAHIABABQAEACACAEQACADABAEQAAADgDAEIAAAFQgBAEgEACIgBAAQgEADgYABIgHAAQgQAAgGgCgAAsAeIAKACQAEACACAEIACADIgCgDQgCgEgEgCIgKgCIgLgBQgFAAgEABIABACIACAGIgCgGIgBgCQAEgBAFAAIALABgAAYAeQgDgFgEgFQAEAFADAFgAAxASIAGACIgGgCQgGgCgJAAQgIAAgJACIABgBIgBgBIAAgEIgCgGIACAGIAAAEIABABIgBABQAJgCAIAAQAJAAAGACgAARAUIAAgCIAAACIgBgBQgEgFgHgEQgFgDgFgBQAFABAFADQAHAEAEAFIABABIAAAAgAgngMIADgFIgDAFgAgBgRIABABIgBgBIAAAAQgFgCgDAAIAAAAIgBAAIAAAAIgBAAIABAAIAAAAIABAAIAAAAQADAAAFACIAAAAgAARASIAAAAg");
	this.shape_1.setTransform(3.9,-2.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-2.6,-8.3,13.8,12);


(lib.元件46 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9C563C").s().p("AnZAlIAAhJIOzAAIAABJg");
	this.shape.setTransform(0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#804731").s().p("AHbAlIAAhJIACAAIBXBJIABAAgAo0AlIABAAIBXhJIAFAAIAABJg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-56.5,-3.8,113.1,7.6);


(lib.元件45 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BB7850").s().p("Ao0AlIABAAIBXhJIO5AAIBXBJIABAAgABbgWIgDABQg1AGgKAIQAAABgBAAQAAABgBAAQAAABAAAAQAAABAAAAIAAACQAGAHA7AIIADAAQBEAHBhAAQBgAABEgHQA+gIAGgHIABgCQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAAAgBgBQgKgIg4gHQhEgHhgAAQhhAAhEAHgAmfgWQg4AHgKAIQAAABgBAAQAAABgBAAQAAABAAAAQAAABAAAAIAAACQAGAHA+AIQBEAHBhAAQBgAABEgHIAHgBQA4gHAFgHIABgCQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAAAgBgBQgJgIgygFIgHgCQhEgHhgAAQhhAAhEAHg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-56.5,-3.8,113.1,7.6);


(lib.元件42 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BB7850").s().p("Ao0AXIABgBIA1gsIAdAAQAAABgBAAQAAABgBAAQAAABAAAAQAAABAAAAIAAACQAGAKA+AGQBEAGBhAAQBgAABEgGIAHAAQA4gHAFgJIABgCQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAAAgBgBIAtAAQAAABgBAAQAAABgBAAQAAABAAAAQAAABAAAAIAAACQAGAKA7AGIADAAQBEAGBhAAQBgAABEgGQA+gGAGgKIABgCQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAAAgBgBIAZAAIA1AsIABABg");
	this.shape.setTransform(0,-20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#915937").s().p("Ao1DHIAAmNIABAAIAAAAIRpAAIAAAAIABAAIAAGNg");
	this.shape_1.setTransform(0.6,2.3,1,1,0,0,0,0.6,0);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-56.6,-22.3,113.3,44.6);


(lib.元件40 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("y", "italic bold 30px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-8.7,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-8.7,-18.6,17.5,37.3);


(lib.元件39 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("2", "30px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-9.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.6,-18.6,20.9,37.5);


(lib.元件38 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("+", "bold 30px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-10.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.6,-18.6,21.3,37.5);


(lib.元件37 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("x", "italic bold 30px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-9.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.6,-18.6,19.2,37.3);


(lib.元件36 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("-", "30px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-10.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.6,-18.6,14.2,37.5);


(lib.元件35 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("3", "30px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-9.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.6,-18.6,20.9,37.5);


(lib.元件34 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("=", "bold 30px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-10.6,-18.6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.6,-18.6,21.3,37.5);


(lib.元件33 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("式", "30px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-17.1,-21.8);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-17.1,-21.8,34.2,43.6);


(lib.元件32 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("原", "30px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-17.1,-21.8);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-17.1,-21.8,34.2,43.6);


(lib.元件22 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQACACAAABQAAAAAAABQgBABAAAAQAAABAAAAQgBAAAAABQgBAAAAABQgBAAAAAAQAAAAgBABQgBAAAAAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-0.2,-1.2,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAFgFAGAAQAIAAAFAFQAFAGAAAGQAAAHgFAGQgFAFgIAAQgGAAgFgFg");
	this.shape_1.setTransform(0.1,-0.3,1,1,0,0,0,0.1,-0.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.8,-1.8,3.7,3.8);


(lib.元件21 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-0.2,-0.9,1,1,0,0,0,0.5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAEgFAHAAQAIAAAEAFQAGAGAAAGQAAAHgGAGQgEAFgIAAQgHAAgEgFg");
	this.shape_1.setTransform(0.3,-0.3,1,1,0,0,0,0.3,-0.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.8,-1.8,3.7,3.8);


(lib.元件20 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQACACAAABQAAAAAAABQgBABAAAAQAAABAAAAQgBAAAAABQgBAAAAABQgBAAAAAAQAAAAgBABQgBAAAAAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-0.2,-1.2,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAFgFAGAAQAIAAAFAFQAFAGAAAGQAAAHgFAGQgFAFgIAAQgGAAgFgFg");
	this.shape_1.setTransform(0.1,-0.3,1,1,0,0,0,0.1,-0.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.8,-1.8,3.7,3.8);


(lib.元件19 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-0.2,-0.9,1,1,0,0,0,0.5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAEgFAHAAQAIAAAEAFQAGAGAAAGQAAAHgGAGQgEAFgIAAQgHAAgEgFg");
	this.shape_1.setTransform(0.3,-0.3,1,1,0,0,0,0.3,-0.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.8,-1.8,3.7,3.8);


(lib.元件18 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQABAAAAABQAAAAABAAQAAAAABABQACACAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQgBAAAAABQgBAAAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-0.2,-1.2,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAFgFAGAAQAIAAAFAFQAFAGAAAGQAAAHgFAGQgFAFgIAAQgGAAgFgFg");
	this.shape_1.setTransform(0.1,-0.3,1,1,0,0,0,0.1,-0.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.8,-1.9,3.7,3.8);


(lib.元件17 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAgBABQgCACgCAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-0.2,-0.9,1,1,0,0,0,0.5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAEgFAHAAQAIAAAEAFQAGAGAAAGQAAAHgGAGQgEAFgIAAQgHAAgEgFg");
	this.shape_1.setTransform(0.3,-0.3,1,1,0,0,0,0.3,-0.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.8,-1.9,3.7,3.8);


(lib.元件14_1 = function() {
	this.initialize();

	// 图层 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAfBiQgJgDgEgKQgDgIADgKQAEgJAJgEQAJgDAJADQAJAEADAJQAEAJgDAJQgEAKgJADQgEACgFAAQgFAAgEgCgAALANQgCgIACgOQABgQgBgJQgBgJgEgLQgGgSgLgGQgLgFgJAEQgIADgDAGQgCAFABADQABACAEADQALAJADAHQADAGgDAGQgDAHgHADQgHADgHgDQgIgDgDgJQgHgQAJgSQAIgRAZgLQAZgLASAHQATAHAHARQAGANgDAOQgCAOgPAVQgJANgBAJQgDAIAGAPIgFADQgHgPgBgJg");

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-6.4,-10.1,12.8,20.2);


(lib.元件12 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EBEBE9").s().p("AguAJIAAABQADgJAKgFQAOgKATAAQARAAANAHIAEADIACABQAJAFACAIQgUAFgXAAQgWAAgcgGg");
	this.shape.setTransform(1.1,4.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A3222D").s().p("AgbADQgMgCAAgBIAAAAIABAAIALgBQAMgBAPgBQAQABAMABQAMABAAAAIAAAAQAAABgMACIgcAAIgbAAg");
	this.shape_1.setTransform(-1.7,1.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D6313F").s().p("AgxATIACgnQAAABAMACIAcABIAbgBQAMgCAAgBIASAVQgOgFgRAAQgTAAgNAIQgLAHgCAJIgLABQgGAAgGgCg");
	this.shape_2.setTransform(-0.9,3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DBDBDB").s().p("AgGAJIgdgDIgIgCQgLgBgEgDIAAgJQALAEALgDIABgBQA0AJApgIIABACIAAAIIgBADQgIAFggAAIgYgBg");
	this.shape_3.setTransform(0,6.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A14523").s().p("AgXAtQgKgGAAgJIAAg6QAAgKAKgHQAJgGAOAAQAOAAAKAGQAKAHAAAKIAAA6QAAAJgKAGQgKAHgOAAQgOAAgJgHg");
	this.shape_4.setTransform(-1.9,-2.4,1.199,0.987,0,0,180,0.2,0);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.9,-7.6,11.9,15.2);


(lib.元件11 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DBDBDB").s().p("Ag5AFIgBgDIAAgIIABgCQApAIA0gJIABABQALADALgEIAAAJQgEADgLABIgIACIgdADIgYABQggAAgIgFg");
	this.shape.setTransform(0,6.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBEBE9").s().p("AguAKQACgIAJgFIACgBIAEgDQANgHAQAAQAUAAAOAKQAKAFADAJIAAgBQgcAGgWAAQgXAAgUgFg");
	this.shape_1.setTransform(-1,4.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D6313F").s().p("AAcAUQgEgJgKgHQgOgIgTAAQgQAAgOAFIASgVQAAABAMACIAaABIAdgBQAMgCAAgBIABAnQgFACgGAAIgKgBg");
	this.shape_2.setTransform(1,3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A3222D").s().p("AgbADQgMgCAAgBIAAAAQAAAAAMgBQAMgBAPgBQAQABAMABIAMABIAAAAIAAAAQAAABgMACIgcAAIgbAAg");
	this.shape_3.setTransform(1.8,1.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A14523").s().p("AgXAtQgKgGAAgJIAAg6QAAgKAKgHQAJgGAOAAQAOAAAKAGQAKAHAAAKIAAA6QAAAJgKAGQgKAHgOAAQgOAAgJgHg");
	this.shape_4.setTransform(1.8,-2.4,1.199,0.987,0,0,0,0.1,0);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.9,-7.6,11.9,15.2);


(lib.元件10_1 = function() {
	this.initialize();

	// 图层 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D6313F").s().p("AgwATIABgnQAAABAMACIAdABIAagBQAMgCAAgBIARAVQgNgFgQAAQgUAAgNAIQgKAHgEAJIgKABQgGAAgFgCg");
	this.shape_1.setTransform(-0.9,3.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A3222D").s().p("AgbADQgMgCAAgBIAAAAIAAAAIAMgBQAMgBAPgBQAQABAMABQAMABAAAAIAAAAQAAABgMACIgcAAIgbAAg");
	this.shape_2.setTransform(-1.7,1.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EBEBE9").s().p("AguAJIAAABQADgJAKgFQAOgKATAAQARAAANAHIAEADIACABQAJAFACAIQgUAFgXAAQgWAAgcgGg");
	this.shape_3.setTransform(1,4.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DBDBDB").s().p("AgGAJIgdgDIgIgCQgLgBgEgDIAAgJQALAEALgDIABgBQA0AJApgIIABACIAAAIIgBADQgIAFggAAIgYgBg");
	this.shape_4.setTransform(0,6.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A14523").s().p("AgXAtQgKgGAAgJIAAg6QAAgKAKgHQAJgGAOAAQAOAAAKAGQAKAHAAAKIAAA6QAAAJgKAGQgKAHgOAAQgOAAgJgHg");
	this.shape_5.setTransform(-1.5,-2.4,1.199,0.987,0,0,180,0.1,0);

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.9,-7.6,11.9,15.2);


(lib.元件9 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DBDBDB").s().p("Ag5AFIgBgDIAAgIIABgCQApAIA0gJIABABQALADALgEIAAAJQgEADgLABIgIACIgdADIgYABQggAAgIgFg");
	this.shape.setTransform(0,6.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBEBE9").s().p("AguAKQACgIAJgFIACgBIAEgDQANgHAQAAQAUAAAOAKQAKAFADAJIAAgBQgcAGgWAAQgXAAgUgFg");
	this.shape_1.setTransform(-1.1,4.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D6313F").s().p("AAbAUQgCgJgLgHQgOgIgSAAQgRAAgOAFIASgVQAAABAMACIAbABIAcgBQAMgCAAgBIACAnQgGACgGAAIgLgBg");
	this.shape_2.setTransform(0.9,3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A3222D").s().p("AgbADQgMgCAAgBIAAAAQAAAAAMgBQAMgBAPgBQAQABAMABIALABIABAAIAAAAQAAABgMACIgcAAIgbAAg");
	this.shape_3.setTransform(1.7,1.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A14523").s().p("AgXAtQgKgGAAgJIAAg6QAAgKAKgHQAJgGAOAAQAOAAAKAGQAKAHAAAKIAAA6QAAAJgKAGQgKAHgOAAQgOAAgJgHg");
	this.shape_4.setTransform(2,-2.4,1.199,0.987,0,0,0,0.3,0);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.9,-7.6,11.9,15.2);


(lib.元件8 = function() {
	this.initialize();

	// 图层 1
	this.text = new cjs.Text("：", "30px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 30;
	this.text.setTransform(-17.1,-21.8);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-17.1,-21.8,34.2,43.6);


(lib.元件7 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABACQIAAg+IhEAAIAAgUIBEAAIAAgqIgjAAIgOAgQgJgFgIgEQAOgjAKgiIAVAGIgIAUIAdAAIAAgdIAVAAIAAAdIA1AAIAAAUIg1AAIAAAqIA8AAIAAAUIg8AAIAAA+gAiPCCQAVghAAg2IAAhhIgIAKIgOgRQAggjAUgvIAVAGIgNAXIA3AAIAAASIgVAgIAlAAIAACuQAAAegdAAIgaAAIgCgUIAZACQAOAAgBgPIAAgvIgaAAIAAA2IgTAAIAAg2IgaAAQgDA3gVAdQgHgIgJgGgAg6ArIAaAAIAAglIgaAAgAhnArIAaAAIAAglIgaAAgAg6gKIAaAAIAAglIgaAAgAhngKIAaAAIAAglIgaAAgAhyhAIAoAAIAWggIgqAAQgKARgKAPgAgLgqQAWgNAKgQQAIgNABgYIgeAAIAAgTICBAAIgCA1QgDAkgjAAIgfgBIgDgYQAUADANAAQAQAAABgRIACgfIg3AAQgCAegJAQQgLAVgcASIgNgTg");
	this.shape.setTransform(-0.2,1.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-17.1,-21.8,34.2,43.6);


(lib.元件2 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFE25D").ss(6,1,1).p("Ah+g+QBnBiCWAb");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-15.7,-9.4,31.4,18.8);


(lib.元件1 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFE25D").ss(6,1,1).p("AB/g+QhoBRiVAs");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-15.7,-9.4,31.4,18.8);


(lib.囧_1_1_36543 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#522C30").s().p("ABrAOQgIgJgMADQgFABgFgCQgFgDgBgEQgCgGAEgEQACgFAGgBQAbgGATAUQAEACAAAGQgBAGgEADQgEAEgFAAQgGgBgEgEgAh+APQgEgFAAgFQAAgFAFgDQAUgTAbAHQAFACADAFQACAFgBADQgCAFgEADQgFADgGgCQgLgDgKAJQgEAEgGAAQgFAAgEgEg");
	this.shape.setTransform(0.3,-6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(35).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(28).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(176).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(259));

	// 图层 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBCF00").s().p("Ag6ARIADgIIAHgJIAFgFIACgBQASgRAXAAQAZAAATASQAKAJAFANQgkAHgcAAQgdAAgYgHg");
	this.shape_1.setTransform(7.8,-2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FBCF00").s().p("AgrgCIgDgDQAugQAvAQIgDADQgTAQgZAAQgZAAgSgQg");
	this.shape_2.setTransform(7.8,6.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FBCF00").s().p("Ag6ARIAEgIIAGgJIAFgFIACgBQASgRAXAAQAaAAASASQAKAJAFANQgkAHgcAAQgdAAgYgHg");
	this.shape_3.setTransform(-7.6,-2.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FBCF00").s().p("AgrgCIgDgDQAugRAvARIgDADQgTARgZAAQgZAAgSgRg");
	this.shape_4.setTransform(-7.6,6.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#998B61").ss(0.3,1,1).p("AAOgDQA7ARBCgRAiKgDQA+AQA/gQ");
	this.shape_5.setTransform(0.1,2.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FBCF00").s().p("AAgAsQgSgSAAgaQAdAKAgAAQAfAAAhgKQAAAZgSATQgTASgaAAQgZAAgTgSgAh4AsQgSgSAAgaQAfAJAfAAQAfAAAggJQAAAZgSATQgSASgbAAQgaAAgSgSgABLAKQggAAgdgKIAAAAQAAgZASgRQATgTAZAAQAaAAATATIAGAGIAEAHQAIAOAAAPQghAKgfAAIAAAAgAhMAJQgfAAgfgJIAAAAQAAgOAHgMIAGgKIAFgGIACgCQASgRAYAAQAbAAASATQASARAAAZQggAJgfAAIAAAAgACLAAIAAAAgAAOAAIAAAAgAgNAAIAAAAgAiKAAIAAAAg");
	this.shape_6.setTransform(0.1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},35).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},28).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},176).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).wait(259));

	// 图层 6
	this.instance = new lib.元件19("synched",0);
	this.instance.setTransform(-6.2,1.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(106).to({_off:false},0).to({x:-10.7},8).wait(94).to({startPosition:0},0).to({x:-8.1,y:-2.3},7).to({_off:true},36).wait(265));

	// 图层 2
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_7.setTransform(-6.4,0.7,1,1,0,0,0,0.5,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAFgFAGAAQAHAAAGAFQAFAGAAAGQAAAHgFAGQgGAFgHAAQgGAAgFgFg");
	this.shape_8.setTransform(-5.9,1.4,1,1,0,0,0,0.3,-0.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQACACAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_9.setTransform(6.4,0.4,1,1,0,0,0,0.4,0);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMANQgFgGAAgHQAAgGAFgGQAGgFAGAAQAHAAAGAFQAFAGAAAGQAAAHgFAGQgGAFgHAAQgGAAgGgFg");
	this.shape_10.setTransform(6.9,1.4,1,1,0,0,0,0.2,-0.3);

	this.instance_1 = new lib.元件20("synched",0);
	this.instance_1.setTransform(6.7,1.7);
	this.instance_1._off = true;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_11.setTransform(-11.2,0.7,1,1,0,0,0,0.5,0);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgMANQgFgGAAgHQAAgGAFgGQAGgFAGAAQAHAAAFAFQAGAGAAAGQAAAHgGAGQgFAFgHAAQgGAAgGgFg");
	this.shape_12.setTransform(-10.7,1.4,1,1,0,0,0,0.3,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]}).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},35).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},28).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.instance_1}]},31).to({state:[{t:this.instance_1}]},8).to({state:[{t:this.instance_1}]},94).to({state:[{t:this.instance_1}]},7).to({state:[]},36).to({state:[{t:this.shape_10,p:{x:6.9}},{t:this.shape_9,p:{x:6.4}},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[{t:this.shape_10,p:{x:4.2}},{t:this.shape_9,p:{x:3.7}},{t:this.shape_12},{t:this.shape_11}]},2).to({state:[{t:this.shape_10,p:{x:4.2}},{t:this.shape_9,p:{x:3.7}},{t:this.shape_12},{t:this.shape_11}]},2).wait(259));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(106).to({_off:false},0).to({x:3.9},8).wait(94).to({startPosition:0},0).to({x:7.6,y:-2.3},7).to({_off:true},36).wait(265));

	// 图层 1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(53,39,21,0.502)").ss(0.3,2,1).p("ACEgdQAIAOAAAPQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgYASgSQASgTAaAAQAaAAATATIAOgKACEgdIAMgGACAgkQACAEACADACAgkIANgIAB6gqQADADADADAiDgbIgLgIAiDgbQADgFAEgFIgLgIAh8glQACgDADgCQABgCABAAIgKgKAh1gsQASgRAYAAQAaAAATATQASASAAAYQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgOAGgN");
	this.shape_13.setTransform(0,1.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAgAsQgSgTAAgZQAAgZASgRQATgTAZAAQAaAAATATIAGAGIAEAHQAIAOAAAPQAAAZgSATQgTASgaAAQgZAAgTgSgAh4AsQgSgTAAgZQAAgOAHgMIAGgKIAFgGIACgCQASgRAYAAQAbAAASATQASARAAAZQAAAZgSATQgSASgbAAQgaAAgSgSg");
	this.shape_14.setTransform(0.1,1.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(53,39,21,0.502)").ss(0.3,2,1).p("AB6gqQADADADADIANgIACAgkQACAEACADIAMgGAB6gqIAOgKACEgdQAIAOAAAPQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgYASgSQASgTAaAAQAaAAATATAh1gsQASgRAYAAQAaAAATATQASASAAAYQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgOAGgNIgLgIAh1gsIgKgKAh8glQACgDADgCQABgCABAAAh8glIgLgIAiDgbQADgFAEgF");
	this.shape_15.setTransform(0,1.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(53,39,21,0.502)").ss(0.3,2,1).p("ACEgdQAIAOAAAPQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgYASgSQASgTAaAAQAaAAATATIAOgKACEgdIAMgGACAgkQACAEACADACAgkIANgIAB6gqQADADADADAiDgbQADgFAEgFIgLgIAh8glQACgDADgCQABgCABAAIgKgKAiDgbIgLgIAh1gsQASgRAYAAQAaAAATATQASASAAAYQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgOAGgN");
	this.shape_16.setTransform(0,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13}]}).to({state:[{t:this.shape_14},{t:this.shape_15}]},35).to({state:[{t:this.shape_14},{t:this.shape_16}]},2).to({state:[{t:this.shape_14},{t:this.shape_15}]},2).to({state:[{t:this.shape_14},{t:this.shape_13}]},2).to({state:[{t:this.shape_14},{t:this.shape_15}]},28).to({state:[{t:this.shape_14},{t:this.shape_16}]},2).to({state:[{t:this.shape_14},{t:this.shape_15}]},2).to({state:[{t:this.shape_14},{t:this.shape_13}]},2).to({state:[{t:this.shape_14},{t:this.shape_15}]},176).to({state:[{t:this.shape_14},{t:this.shape_16}]},2).to({state:[{t:this.shape_14},{t:this.shape_15}]},2).to({state:[{t:this.shape_14},{t:this.shape_13}]},2).wait(259));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.8,-8.8,31.6,17.7);


(lib.kk_34905 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.kk_52377("synched",0);
	this.instance.setTransform(15,15,1,1,0,0,0,15,15);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00DEFF").ss(2,1,1).p("ACWAAQAAA9gsAtQgtAsg9AAQg8AAgtgsQgsgtAAg9QAAg8AsgtQAtgsA8AAQA9AAAtAsQAsAtAAA8g");
	this.shape.setTransform(15,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#151515").s().p("AhoBpQgsgsgBg9QABg9AsgrQArgsA9gBQA9ABAsAsQAtArgBA9QABA9gtAsQgsAtg9gBQg9ABgrgtg");
	this.shape_1.setTransform(15,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,32,32);


(lib.元件13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#522C30").s().p("ABrAOQgIgJgMADQgFABgFgCQgFgDgBgEQgCgGAEgEQACgFAGgBQAbgGATAUQAEACAAAGQgBAGgEADQgEAEgFAAQgGgBgEgEgAh+APQgEgFAAgFQAAgFAFgDQAUgTAbAHQAFACADAFQACAFgBADQgCAFgEADQgFADgGgCQgLgDgKAJQgEAEgGAAQgFAAgEgEg");
	this.shape.setTransform(0.3,-6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(35).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(30).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(6).to({y:-6.2},0).wait(1).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(1).to({y:-6.9},0).wait(57).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(99).to({y:-6.2},0).wait(2).to({y:-5.5},0).wait(2).to({y:-6.2},0).wait(2).to({y:-6.9},0).wait(177));

	// 图层 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBCF00").s().p("Ag6ARIADgIIAHgJIAFgFIACgBQASgRAXAAQAZAAATASQAKAJAFANQgkAHgcAAQgdAAgYgHg");
	this.shape_1.setTransform(7.8,-2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FBCF00").s().p("AgrgCIgDgDQAugQAvAQIgDADQgTAQgZAAQgZAAgSgQg");
	this.shape_2.setTransform(7.8,6.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FBCF00").s().p("Ag6ARIAEgIIAGgJIAFgFIACgBQASgRAXAAQAaAAASASQAKAJAFANQgkAHgcAAQgdAAgYgHg");
	this.shape_3.setTransform(-7.6,-2.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FBCF00").s().p("AgrgCIgDgDQAugRAvARIgDADQgTARgZAAQgZAAgSgRg");
	this.shape_4.setTransform(-7.6,6.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#998B61").ss(0.3,1,1).p("AAOgDQA7ARBCgRAiKgDQA+AQA/gQ");
	this.shape_5.setTransform(0.1,2.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FBCF00").s().p("AAgAsQgSgSAAgaQAdAKAgAAQAfAAAhgKQAAAZgSATQgTASgaAAQgZAAgTgSgAh4AsQgSgSAAgaQAfAJAfAAQAfAAAggJQAAAZgSATQgSASgbAAQgaAAgSgSgABLAKQggAAgdgKIAAAAQAAgZASgRQATgTAZAAQAaAAATATIAGAGIAEAHQAIAOAAAPQghAKgfAAIAAAAgAhMAJQgfAAgfgJIAAAAQAAgOAHgMIAGgKIAFgGIACgCQASgRAYAAQAbAAASATQASARAAAZQggAJgfAAIAAAAgACLAAIAAAAgAAOAAIAAAAgAgNAAIAAAAgAiKAAIAAAAg");
	this.shape_6.setTransform(0.1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},35).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},30).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},6).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},1).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},57).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},99).to({state:[{t:this.shape_6},{t:this.shape_5}]},2).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[]},2).wait(177));

	// 图层 6
	this.instance = new lib.元件17("synched",0);
	this.instance.setTransform(-6.2,-2.2);
	this.instance._off = true;

	this.instance_1 = new lib.元件21("synched",0);
	this.instance_1.setTransform(-11.3,1.7);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(98).to({_off:false},0).to({x:-3.6,y:1.1},11).wait(35).to({startPosition:0},0).to({_off:true},2).wait(286));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(204).to({_off:false},0).to({x:-7.3,y:-2.3},6).to({_off:true},39).wait(183));

	// 图层 2
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_7.setTransform(-6.4,0.7,1,1,0,0,0,0.5,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAFgFAGAAQAHAAAGAFQAFAGAAAGQAAAHgFAGQgGAFgHAAQgGAAgFgFg");
	this.shape_8.setTransform(-5.9,1.4,1,1,0,0,0,0.3,-0.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQACACAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_9.setTransform(6.4,0.4,1,1,0,0,0,0.4,0);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMANQgFgGAAgHQAAgGAFgGQAGgFAGAAQAHAAAGAFQAFAGAAAGQAAAHgFAGQgGAFgHAAQgGAAgGgFg");
	this.shape_10.setTransform(6.9,1.4,1,1,0,0,0,0.2,-0.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAgBABQgCACgCAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_11.setTransform(-6.4,-2.7,1,1,0,0,0,0.5,0);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_12.setTransform(-6.4,-3.1,1,1,0,0,0,0.5,0);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_13.setTransform(7.6,-3.4,1,1,0,0,0,0.4,0);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgLANQgGgGAAgHQAAgGAGgGQAFgFAGAAQAIAAAFAFQAFAGAAAGQAAAHgFAGQgFAFgIAAQgGAAgFgFg");
	this.shape_14.setTransform(8.1,-2.5,1,1,0,0,0,0.2,-0.3);

	this.instance_2 = new lib.元件18("synched",0);
	this.instance_2.setTransform(7.9,-2.2);
	this.instance_2._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgMANQgFgGAAgHQAAgGAFgGQAFgFAHAAQAIAAAFAFQAFAGAAAGQAAAHgFAGQgFAFgIAAQgHAAgFgFg");
	this.shape_15.setTransform(-11,1.4,1,1,0,0,0,0.3,-0.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQACACAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_16.setTransform(3.4,0.4,1,1,0,0,0,0.4,0);

	this.instance_3 = new lib.元件22("synched",0);
	this.instance_3.setTransform(3.7,1.7);
	this.instance_3._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBACgCIADgCQACAAACACQACACAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAgBABQgCACgCAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_17.setTransform(-3.9,0.7,1,1,0,0,0,0.5,0);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgMANQgFgGAAgHQAAgGAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAGQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_18.setTransform(-3.4,1.4,1,1,0,0,0,0.3,-0.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBACgCQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQACACAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABQgBAAAAABQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_19.setTransform(11.4,0.4,1,1,0,0,0,0.4,0);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgMANQgFgGAAgHQAAgGAFgGQAGgFAGAAQAIAAAFAFQAFAGAAAGQAAAHgFAGQgFAFgIAAQgGAAgGgFg");
	this.shape_20.setTransform(11.9,1.4,1,1,0,0,0,0.2,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]}).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},35).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},2).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},2).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},2).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},30).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},2).to({state:[{t:this.shape_10,p:{y:-2.1,x:6.9}},{t:this.shape_9,p:{y:-3}},{t:this.shape_8,p:{y:-2.1}},{t:this.shape_11}]},2).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_8,p:{y:-2.5}},{t:this.shape_12}]},2).to({state:[{t:this.shape_10,p:{y:-2.1,x:6.9}},{t:this.shape_9,p:{y:-3}},{t:this.shape_8,p:{y:-2.1}},{t:this.shape_11}]},6).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},1).to({state:[{t:this.shape_10,p:{y:-2.1,x:6.9}},{t:this.shape_9,p:{y:-3}},{t:this.shape_8,p:{y:-2.1}},{t:this.shape_11}]},2).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_8,p:{y:-2.5}},{t:this.shape_12}]},1).to({state:[{t:this.instance_2}]},11).to({state:[{t:this.instance_2}]},11).to({state:[{t:this.instance_2}]},35).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},2).to({state:[{t:this.shape_10,p:{y:1.4,x:3.9}},{t:this.shape_16},{t:this.shape_15},{t:this.shape_7,p:{x:-11.5}}]},2).to({state:[{t:this.shape_10,p:{y:1.4,x:3.9}},{t:this.shape_16},{t:this.shape_15},{t:this.shape_7,p:{x:-11.5}}]},2).to({state:[{t:this.instance_3}]},54).to({state:[{t:this.instance_3}]},6).to({state:[]},39).to({state:[{t:this.shape_10,p:{y:1.4,x:6.9}},{t:this.shape_9,p:{y:0.4}},{t:this.shape_8,p:{y:1.4}},{t:this.shape_7,p:{x:-6.4}}]},2).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]},2).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]},2).wait(177));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(98).to({_off:false},0).to({x:11.4,y:1.4},11).wait(35).to({startPosition:0},0).to({_off:true},2).wait(286));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(204).to({_off:false},0).to({x:8.4,y:-2.4},6).to({_off:true},39).wait(183));

	// 图层 1
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(53,39,21,0.502)").ss(0.3,2,1).p("ACEgdQAIAOAAAPQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgYASgSQASgTAaAAQAaAAATATIAOgKACEgdIAMgGACAgkQACAEACADACAgkIANgIAB6gqQADADADADAiDgbIgLgIAiDgbQADgFAEgFIgLgIAh8glQACgDADgCQABgCABAAIgKgKAh1gsQASgRAYAAQAaAAATATQASASAAAYQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgOAGgN");
	this.shape_21.setTransform(0,1.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAgAsQgSgTAAgZQAAgZASgRQATgTAZAAQAaAAATATIAGAGIAEAHQAIAOAAAPQAAAZgSATQgTASgaAAQgZAAgTgSgAh4AsQgSgTAAgZQAAgOAHgMIAGgKIAFgGIACgCQASgRAYAAQAbAAASATQASARAAAZQAAAZgSATQgSASgbAAQgaAAgSgSg");
	this.shape_22.setTransform(0.1,1.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(53,39,21,0.502)").ss(0.3,2,1).p("AB6gqQADADADADIANgIACAgkQACAEACADIAMgGAB6gqIAOgKACEgdQAIAOAAAPQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgYASgSQASgTAaAAQAaAAATATAh1gsQASgRAYAAQAaAAATATQASASAAAYQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgOAGgNIgLgIAh1gsIgKgKAh8glQACgDADgCQABgCABAAAh8glIgLgIAiDgbQADgFAEgF");
	this.shape_23.setTransform(0,1.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(53,39,21,0.502)").ss(0.3,2,1).p("ACEgdQAIAOAAAPQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgYASgSQASgTAaAAQAaAAATATIAOgKACEgdIAMgGACAgkQACAEACADACAgkIANgIAB6gqQADADADADAiDgbQADgFAEgFIgLgIAh8glQACgDADgCQABgCABAAIgKgKAiDgbIgLgIAh1gsQASgRAYAAQAaAAATATQASASAAAYQAAAagSASQgTASgaAAQgaAAgSgSQgSgSAAgaQAAgOAGgN");
	this.shape_24.setTransform(0,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21}]}).to({state:[{t:this.shape_22},{t:this.shape_23}]},35).to({state:[{t:this.shape_22},{t:this.shape_24}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},2).to({state:[{t:this.shape_22},{t:this.shape_21}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},30).to({state:[{t:this.shape_22},{t:this.shape_24}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},2).to({state:[{t:this.shape_22},{t:this.shape_21}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},6).to({state:[{t:this.shape_22},{t:this.shape_24}]},1).to({state:[{t:this.shape_22},{t:this.shape_23}]},2).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_22},{t:this.shape_23}]},57).to({state:[{t:this.shape_22},{t:this.shape_24}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},2).to({state:[{t:this.shape_22},{t:this.shape_21}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},99).to({state:[{t:this.shape_22},{t:this.shape_24}]},2).to({state:[{t:this.shape_22},{t:this.shape_23}]},2).to({state:[{t:this.shape_22},{t:this.shape_21}]},2).wait(177));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.8,-8.8,31.6,17.7);


(lib.元件6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 2
	this.instance = new lib.囧_1_1_36543("synched",0);
	this.instance.setTransform(-0.2,-16.7,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(448));

	// 图层 1
	this.instance_1 = new lib.元件14("synched",0);
	this.instance_1.setTransform(-17.2,-7.4,0.711,0.711,8.5,0,0,3.5,5);

	this.instance_2 = new lib.元件6("synched",0);
	this.instance_2.setTransform(1.8,-4.1,0.656,0.656,-10.7,0,0,8.9,3.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F9C519").s().p("AgtAvQgUgUAAgbQAAgaAUgSQATgVAaAAQAbAAAUAVQATASAAAaQAAAbgTAUQgUATgbAAQgaAAgTgTg");
	this.shape_2.setTransform(7.9,-14.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F9C519").s().p("AguAvQgTgUAAgbQAAgaATgSQAUgVAaAAQAbAAATAVQAUASAAAaQAAAbgUAUQgTATgbAAQgaAAgUgTg");
	this.shape_3.setTransform(-8,-14.1);

	this.instance_3 = new lib.元件10("synched",0);
	this.instance_3.setTransform(-18.7,1.3,0.342,0.342,0,0,0,2.5,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DB6940").s().p("AANAnIgxg3QgCgFAAgFQACgGAEgEQAFgEAGgBQAFgBADAEIAxA4QADAEAAAFQgBAGgFAFQgFAEgFAAIgDAAQgEAAgDgDg");
	this.shape_4.setTransform(-20.4,-1.2,1,1,0,0,0,0.3,-0.2);

	this.instance_4 = new lib.元件10("synched",0);
	this.instance_4.setTransform(18.3,1.8,0.342,0.342,0,0,0,3.5,3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DB6940").s().p("AgWAqQgFAAgFgEQgFgFgBgGQAAgFADgEIAwg4QAEgEAFABQAGABAFAEQAEAEACAGQAAAFgCAFIgxA3QgDADgEAAIgDAAg");
	this.shape_5.setTransform(20.4,-1.2,1,1,0,0,0,-0.3,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BD4D22").s().p("AgDgRIAIACQgDAVgDAMQgDgSABgRg");
	this.shape_6.setTransform(-23.1,8.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#AA4B1D").s().p("AgEAQQAEgMACgVIACAAIABAAQgEAZgEAKIgBgCg");
	this.shape_7.setTransform(-22.8,8.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9C4419").s().p("AACAMQgEgLgDgOIAAgBIAAAAIAHgBIAEAQIgBAPIgDgEg");
	this.shape_8.setTransform(23.3,8.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9F461B").s().p("AgBgHIABgBIACAAIgBARg");
	this.shape_9.setTransform(23.8,7.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EC7041").s().p("AirABIgxgCIAAgFIAxAGQBIADBlABQBmgBBJgDIAsgFIAAAFIgsABQhJAGhmAAQhlAAhIgGg");
	this.shape_10.setTransform(0,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CD5629").s().p("AiMBsQgOgKgOgMQgKgKgJgLQgKgNgJgPQgVglgHgwQAHgKADgaIACgPIAAgFIAAgHIAAgTIAAgOIAwAFQBJAFBlAAQBmAABIgFIAsgEIAAAOIABAOIABAKIADAVIABABQACAQAHALIACAFQgFAmgNAeQgSAngfAeQhAA7hoAAQhTAAg5glg");
	this.shape_11.setTransform(0.3,15.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DBAF3E").s().p("AjDAzIgBgBIgHgHIgBgCQAcAXAjANQAeAKAkADIAbABIABAAQAnAAAfgIQA5gMArgjQBBgzARhdQgFBng/A4Qg/A6hnAAQhnAAg/g6g");
	this.shape_12.setTransform(3.2,18.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFF8A1").s().p("AhrAAQBIhyBcAAQA3AAAxAnQgrgXgvAAQhiAAhMBnQgnA1gSA5QARg9Akg2g");
	this.shape_13.setTransform(-5.6,-18.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFE25D").s().p("AgSEYIgbgBQgkgDgegKQgkgNgcgXQg5g8gDhmIAAgFIAAgDIAAgDIABgUQACgzAOgxQASg6Ang0QBMhqBiAAQAvAAArAYQAMAKANANQAUAXATAdQAcAtARAwQAYBGAABKIgBAWQgRBdhBA1QgrAjg5AMQgiAIgkAAIgBAAg");
	this.shape_14.setTransform(0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.instance_4},{t:this.shape_4},{t:this.instance_3},{t:this.shape_3},{t:this.shape_2},{t:this.instance_2},{t:this.instance_1}]}).wait(448));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.6,-29.8,49.3,59.7);


(lib.元件5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 5
	this.instance = new lib.元件14_1("synched",0);
	this.instance.setTransform(-13.9,-28.1,0.1,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(82).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-20.8,y:-42.3,alpha:1},4).to({scaleX:0.9,scaleY:0.9,x:-19.4,y:-38.3},5).to({scaleX:1,scaleY:1,x:-19.8,y:-39.4},5).wait(46).to({startPosition:0},0).to({x:-18.8,y:-37.3},3).to({x:-25.5,y:-52.8,alpha:0},5).to({_off:true},1).wait(371));

	// 图层 3
	this.instance_1 = new lib.元件13("synched",0);
	this.instance_1.setTransform(-0.2,-16.7,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(522));

	// 图层 1
	this.instance_2 = new lib.元件14("synched",0);
	this.instance_2.setTransform(-17,-7.7,0.711,0.711,8.5,0,0,3.6,4.5);

	this.instance_3 = new lib.元件6("synched",0);
	this.instance_3.setTransform(1.7,-4.1,0.656,0.656,-10.7,0,0,8.8,3.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9C519").s().p("AgtAvQgUgUAAgbQAAgaAUgSQATgVAaAAQAbAAAUAVQATASAAAaQAAAbgTAUQgUATgbAAQgaAAgTgTg");
	this.shape.setTransform(7.9,-14.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F9C519").s().p("AguAvQgTgUAAgbQAAgaATgSQAUgVAaAAQAbAAATAVQAUASAAAaQAAAbgUAUQgTATgbAAQgaAAgUgTg");
	this.shape_1.setTransform(-8,-14.1);

	this.instance_4 = new lib.元件10("synched",0);
	this.instance_4.setTransform(-18.7,1.3,0.342,0.342,0,0,0,2.4,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DB6940").s().p("AANAnIgxg3QgCgFAAgFQACgGAEgEQAFgEAGgBQAFgBADAEIAxA4QADAEAAAFQgBAGgFAFQgFAEgFAAIgDAAQgEAAgDgDg");
	this.shape_2.setTransform(-20.3,-1.2,1,1,0,0,0,0.4,-0.2);

	this.instance_5 = new lib.元件10("synched",0);
	this.instance_5.setTransform(18.5,1.8,0.342,0.342,0,0,0,4.4,3.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DB6940").s().p("AgWAqQgFAAgFgEQgFgFgBgGQAAgFADgEIAwg4QAEgEAFABQAGABAFAEQAEAEACAGQAAAFgCAFIgxA3QgDADgEAAIgDAAg");
	this.shape_3.setTransform(20.4,-1.2,1,1,0,0,0,-0.3,-0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BD4D22").s().p("AgDgRIAIACQgDAVgDAMQgDgSABgRg");
	this.shape_4.setTransform(-23.1,8.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#AA4B1D").s().p("AgEAQQAEgMACgVIACAAIABAAQgEAZgEAKIgBgCg");
	this.shape_5.setTransform(-22.8,8.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9C4419").s().p("AACAMQgEgLgDgOIAAgBIAAAAIAHgBIAEAQIgBAPIgDgEg");
	this.shape_6.setTransform(23.3,8.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9F461B").s().p("AgBgHIABgBIACAAIgBARg");
	this.shape_7.setTransform(23.8,7.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EC7041").s().p("AirABIgxgCIAAgFIAxAGQBIADBlABQBmgBBJgDIAsgFIAAAFIgsABQhJAGhmAAQhlAAhIgGg");
	this.shape_8.setTransform(0,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CD5629").s().p("AiMBsQgOgKgOgMQgKgKgJgLQgKgNgJgPQgVglgHgwQAHgKADgaIACgPIAAgGIAAgGIAAgUIAAgNIAwAFQBJAFBlAAQBmAABIgFIAsgEIAAAOIABAOIABAKIADAVIABABQACAQAHALIACAEQgFAngNAeQgSAngfAeQhAA7hoAAQhTAAg5glg");
	this.shape_9.setTransform(0.3,15.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DBAF3E").s().p("AjDAyIgBgBIgHgGIgBgCQAcAXAjAMQAeALAkADIAbABIABAAQAngBAfgHQA5gMArgjQBBgzARhdQgFBmg/A4Qg/A8hngBQhnABg/g8g");
	this.shape_10.setTransform(3.2,18.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFE25D").s().p("AgSEYIgbgBQgkgDgegKQgkgNgcgXQg5g8gDhmIAAgFIAAgDIAAgDIABgUQACgzAOgxQASg6Ang0QBMhqBiAAQAvAAArAYQAMAKANANQAUAXATAdQAcAtARAwQAYBGAABKIgBAWQgRBdhBA1QgrAjg5AMQgiAIgkAAIgBAAg");
	this.shape_11.setTransform(0.2,-0.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFF8A1").s().p("AhrAAQBIhyBcAAQA3AAAxAnQgrgXgvAAQhiAAhMBnQgnA1gSA5QARg9Akg2g");
	this.shape_12.setTransform(-5.6,-18.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance_5},{t:this.shape_2},{t:this.instance_4},{t:this.shape_1},{t:this.shape},{t:this.instance_3},{t:this.instance_2}]}).wait(522));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.6,-29.8,49.3,59.7);


(lib.元件3 = function() {
	this.initialize();

	// 图层 1
	this.instance = new lib.元件45("synched",0);

	this.instance_1 = new lib.元件46("synched",0);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-56.5,-3.8,113.1,7.6);


(lib.元件41 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// （
	this.instance = new lib.元件50("synched",0);
	this.instance.setTransform(-75.8,-16.1,0.2,0.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(216).to({_off:false},0).to({scaleX:1,scaleY:1,x:-78.2,y:-34},4).to({y:-29.5},5).to({y:-31},6).wait(17).to({startPosition:0},0).to({y:-25},4).to({x:-38.9,y:-83.2},5).to({y:-77.6},6).to({y:-79.2},6).wait(117));

	// ）
	this.instance_1 = new lib.元件51("synched",0);
	this.instance_1.setTransform(71.9,-21.8,0.2,0.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(161).to({_off:false},0).to({scaleX:1,scaleY:1,x:75.5,y:-32.5},4).to({y:-30.2},5).to({y:-31},5).wait(81).to({startPosition:0},0).to({y:-23.8},4).to({x:49.7,y:-82.3},5).to({y:-77.3},6).to({y:-79.3},6).wait(109));

	// 图层 24
	this.instance_2 = new lib.囧_1_1_33819("synched",0);
	this.instance_2.setTransform(6.9,-111.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.text = new cjs.Text("-", "30px 'Arial'", "#612C16");
	this.text.lineHeight = 30;
	this.text.setTransform(-2.7,-95.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},278).to({state:[{t:this.instance_2}]},4).to({state:[{t:this.instance_2}]},5).to({state:[{t:this.instance_2}]},5).to({state:[{t:this.instance_2}]},47).to({state:[{t:this.text}]},3).to({state:[{t:this.instance_2}]},4).to({state:[{t:this.text}]},3).to({state:[{t:this.instance_2}]},4).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(278).to({_off:false},0).to({y:-75.2,alpha:1},4).to({y:-81.2},5).to({y:-79.2},5).wait(47).to({x:7.9,y:-77.2},0).to({_off:true},3).wait(4).to({_off:false},0).to({_off:true},3).wait(4).to({_off:false},0).wait(33));

	// y
	this.instance_3 = new lib.元件40("synched",0);
	this.instance_3.setTransform(22.7,-51.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.text_1 = new cjs.Text("y", "italic bold 30px 'Times New Roman'", "#612C16");
	this.text_1.lineHeight = 30;
	this.text_1.setTransform(29.4,-95.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},19).to({state:[{t:this.instance_3}]},4).to({state:[{t:this.instance_3}]},5).to({state:[{t:this.instance_3}]},6).to({state:[{t:this.instance_3}]},222).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_3}]},4).to({state:[{t:this.instance_3}]},5).to({state:[{t:this.instance_3}]},71).to({state:[{t:this.text_1}]},3).to({state:[{t:this.instance_3}]},4).to({state:[{t:this.text_1}]},3).to({state:[{t:this.instance_3}]},4).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(19).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(222).to({startPosition:0},0).to({x:45.5},3).to({x:35.6},4).to({x:37.1},5).wait(71).to({x:38.1,y:-77.2},0).to({_off:true},3).wait(4).to({_off:false},0).to({_off:true},3).wait(4).to({_off:false},0).wait(33));

	// 2
	this.instance_4 = new lib.元件39("synched",0);
	this.instance_4.setTransform(8.6,-51.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.text_2 = new cjs.Text("2", "30px 'Arial'", "#612C16");
	this.text_2.lineHeight = 30;
	this.text_2.setTransform(14.4,-95.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},18).to({state:[{t:this.instance_4}]},4).to({state:[{t:this.instance_4}]},5).to({state:[{t:this.instance_4}]},6).to({state:[{t:this.instance_4}]},223).to({state:[{t:this.instance_4}]},3).to({state:[{t:this.instance_4}]},4).to({state:[{t:this.instance_4}]},5).to({state:[{t:this.instance_4}]},71).to({state:[{t:this.text_2}]},3).to({state:[{t:this.instance_4}]},4).to({state:[{t:this.text_2}]},3).to({state:[{t:this.instance_4}]},4).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(18).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(223).to({startPosition:0},0).to({x:31.4},3).to({x:21.5},4).to({x:23},5).wait(71).to({x:24,y:-77.2},0).to({_off:true},3).wait(4).to({_off:false},0).to({_off:true},3).wait(4).to({_off:false},0).wait(33));

	// +
	this.instance_5 = new lib.元件38("synched",0);
	this.instance_5.setTransform(-7.5,-51.2);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(17).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(224).to({startPosition:0},0).to({x:15.3},3).to({x:5.4},4).to({x:6.9},5).wait(8).to({startPosition:0},0).to({y:-92.7},3).to({y:-52.2,alpha:0},4).to({_off:true},1).wait(102));

	// x
	this.instance_6 = new lib.元件37("synched",0);
	this.instance_6.setTransform(-23.5,-51.2);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.text_3 = new cjs.Text("x", "italic bold 30px 'Times New Roman'", "#612C16");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 30;
	this.text_3.lineWidth = 19;
	this.text_3.setTransform(-10,-95.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},16).to({state:[{t:this.instance_6}]},4).to({state:[{t:this.instance_6}]},5).to({state:[{t:this.instance_6}]},6).to({state:[{t:this.instance_6}]},225).to({state:[{t:this.instance_6}]},3).to({state:[{t:this.instance_6}]},4).to({state:[{t:this.instance_6}]},5).to({state:[{t:this.instance_6}]},71).to({state:[{t:this.text_3,p:{x:-10,textAlign:"center",lineWidth:19}}]},3).to({state:[{t:this.instance_6}]},4).to({state:[{t:this.text_3,p:{x:-17.7,textAlign:"",lineWidth:15}}]},3).to({state:[{t:this.instance_6}]},4).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(16).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(225).to({startPosition:0},0).to({x:-0.7},3).to({x:-10.6},4).to({x:-9.1},5).wait(71).to({x:-8.1,y:-77.2},0).to({_off:true},3).wait(4).to({_off:false},0).to({_off:true},3).wait(4).to({_off:false},0).wait(33));

	// -
	this.instance_7 = new lib.元件36("synched",0);
	this.instance_7.setTransform(-42,-51.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(15).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(356));

	// 3
	this.instance_8 = new lib.元件35("synched",0);
	this.instance_8.setTransform(-58,-51.2);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(14).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(357));

	// =
	this.instance_9 = new lib.元件34("synched",0);
	this.instance_9.setTransform(-74.1,-51.2);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(13).to({_off:false},0).to({y:-93.2,alpha:1},4).to({y:-72.2},5).to({y:-79.2},6).wait(358));

	// 式
	this.instance_10 = new lib.元件33("synched",0);
	this.instance_10.setTransform(-97.6,-53);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(12).to({_off:false},0).to({y:-95,alpha:1},4).to({y:-74},5).to({y:-81},6).wait(359));

	// 原
	this.instance_11 = new lib.元件32("synched",0);
	this.instance_11.setTransform(-127.6,-53);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(11).to({_off:false},0).to({y:-95,alpha:1},4).to({y:-74},5).to({y:-81},6).wait(360));

	// 解：原式=3-（x+2y）
	this.instance_12 = new lib.元件8("synched",0);
	this.instance_12.setTransform(-172.6,-80.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(4).to({_off:false},0).wait(1).to({regX:-0.1,regY:-0.1,x:-169.3,y:-80.9,alpha:0.224},0).wait(1).to({x:-166.7,alpha:0.4},0).wait(1).to({x:-164.6,alpha:0.541},0).wait(1).to({x:-162.9,alpha:0.656},0).wait(1).to({x:-161.5,alpha:0.749},0).wait(1).to({x:-160.3,alpha:0.825},0).wait(1).to({x:-159.4,alpha:0.886},0).wait(1).to({x:-158.7,alpha:0.934},0).wait(1).to({x:-158.1,alpha:0.972},0).wait(1).to({regX:0,regY:0,x:-157.6,y:-80.8,alpha:1},0).wait(372));

	// 解
	this.instance_13 = new lib.元件7("synched",0);
	this.instance_13.setTransform(-187.6,-80.8,0.1,0.1);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:360,alpha:1},3).to({scaleX:0.9,scaleY:0.9},4).to({scaleX:1,scaleY:1},6).wait(372));

	// x-2y
	this.instance_14 = new lib.元件49("synched",0);
	this.instance_14.setTransform(-0.8,8.2,0.1,0.1);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(64).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},4).to({scaleX:0.95,scaleY:0.95},5).to({scaleX:1,scaleY:1},5).wait(246).to({startPosition:0},0).to({scaleY:0.93,y:11.2},5).to({scaleY:1,x:13.5,y:-84.5},3).to({y:-78.9},5).wait(24).to({startPosition:0},0).to({alpha:0},8).wait(17));

	// 图层 3
	this.instance_15 = new lib.元件42("synched",0);
	this.instance_15.setTransform(-0.9,7.7,5.157,5.157);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(59).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},4).to({scaleX:1.05,scaleY:1.05},5).to({scaleX:1,scaleY:1},6).wait(250).to({startPosition:0},0).to({scaleY:0.93,y:10.8},5).to({scaleY:1,x:13.4,y:-85},3).to({y:-79.4},5).wait(28).to({startPosition:0},0).to({alpha:0},4).wait(17));

	// 图层 5
	this.instance_16 = new lib.元件6_1("synched",0);
	this.instance_16.setTransform(24.7,-84.7);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(52).to({_off:false},0).to({scaleX:1.02,scaleY:0.95,y:1.7,alpha:1,startPosition:4},4).to({scaleX:0.98,scaleY:1.01,y:-8,startPosition:9},5).to({scaleX:1.02,scaleY:0.98,y:-1.7,startPosition:15},6).to({scaleX:1,scaleY:1,y:-3.7,startPosition:21},6).wait(237).to({startPosition:257},0).to({y:-2.4,startPosition:259},2).to({y:-3.7,startPosition:261},2).to({y:-2.4,startPosition:264},3).to({y:-3.7,startPosition:266},2).wait(5).to({startPosition:271},0).to({scaleY:0.93,y:0.1,startPosition:274},5).to({scaleY:1,x:39.1,y:-96.4,startPosition:279},3).to({y:-90.8,startPosition:284},5).wait(24).to({startPosition:308},0).to({alpha:0,startPosition:316},8).wait(17));

	// 图层 8
	this.instance_17 = new lib.元件12("synched",0);
	this.instance_17.setTransform(33.9,15.5,1,1,0,0,0,-0.3,-4.5);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(88).to({_off:false},0).to({y:24.3},4).to({y:20.9},5).to({y:21.5},5).wait(222).to({startPosition:0},0).to({scaleY:0.93,y:22.3},5).to({scaleY:1,x:48.3,y:-71.2},3).to({y:-65.6},5).wait(24).to({startPosition:0},0).to({alpha:0},8).wait(17));

	// 图层 9
	this.instance_18 = new lib.元件11("synched",0);
	this.instance_18.setTransform(16.4,15.8,1,1,0,0,0,0.3,-4.2);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(86).to({_off:false},0).to({y:24.6},4).to({y:21.2},5).to({y:21.8},5).wait(224).to({startPosition:0},0).to({scaleY:0.93,y:22.6},5).to({scaleY:1,x:30.7,y:-70.9},3).to({y:-65.3},5).wait(24).to({startPosition:0},0).to({alpha:0},8).wait(17));

	// 图层 6
	this.instance_19 = new lib.元件5("synched",0);
	this.instance_19.setTransform(-26,-84.7);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(48).to({_off:false},0).to({scaleX:1.04,scaleY:0.95,y:1.7,alpha:1,startPosition:4},4).to({scaleX:0.99,scaleY:1.01,y:-8,startPosition:9},5).to({scaleX:1.02,scaleY:0.98,y:-1.7,startPosition:15},6).to({scaleX:1,scaleY:1,y:-3.7,startPosition:21},6).wait(240).to({startPosition:261},0).to({y:-2.3,startPosition:265},2).to({y:-3.7,startPosition:270},2).to({y:-3.2,startPosition:275},3).to({y:-3.7,startPosition:281},2).wait(6).to({startPosition:287},0).to({scaleY:0.93,y:0.1,startPosition:290},5).to({scaleY:1,x:-11.7,y:-96.4,startPosition:295},3).to({y:-90.8,startPosition:300},5).wait(24).to({startPosition:324},0).to({alpha:0,startPosition:332},8).wait(17));

	// 图层 10
	this.instance_20 = new lib.元件10_1("synched",0);
	this.instance_20.setTransform(-16.4,15.8,1,1,0,0,0,0.1,-4.2);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(84).to({_off:false},0).to({y:25.2},4).to({y:21.2},5).to({y:21.8},5).wait(226).to({startPosition:0},0).to({scaleY:0.93,y:22.6},5).to({scaleY:1,x:-2.1,y:-70.9},3).to({y:-65.3},5).wait(24).to({startPosition:0},0).to({alpha:0},8).wait(17));

	// 图层 11
	this.instance_21 = new lib.元件9("synched",0);
	this.instance_21.setTransform(-34.4,16.4,1,1,0,0,0,0.3,-3.6);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(82).to({_off:false},0).to({y:25.8},4).to({y:21.8},5).to({y:22.4},5).wait(228).to({startPosition:0},0).to({scaleY:0.93,y:23.1},5).to({scaleY:1,x:-20,y:-70.3},3).to({y:-64.7},5).wait(24).to({startPosition:0},0).to({alpha:0},8).wait(17));

	// 图层 7
	this.instance_22 = new lib.元件3("synched",0);
	this.instance_22.setTransform(-1,-3.7,0.1,0.1);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(64).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-0.9,y:-15.8},5).to({scaleX:0.95,scaleY:0.95,y:-12.3},5).to({scaleX:1,scaleY:1,y:-13.7},7).wait(243).to({startPosition:0},0).to({scaleY:0.93,y:-9.2},5).to({scaleY:1,x:13.4,y:-106.4},3).to({y:-100.8},5).wait(24).to({startPosition:0},0).to({alpha:0},8).wait(17));

	// 左手
	this.instance_23 = new lib.元件48("synched",0);
	this.instance_23.setTransform(-48,-6.8,1,1,30.2,0,0,2.1,-2.5);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(213).to({_off:false},0).to({rotation:38.7,x:-66,y:-10.1},3).to({rotation:30.5,x:-66.1,y:-6.9},3).to({rotation:32,y:-7.5},4).wait(25).to({startPosition:0},0).to({regX:2.3,rotation:23.8,x:-65.9,y:-3.8},4).to({regX:2.2,rotation:55,x:-62.8,y:-17.2},4).to({regX:2.3,rotation:51,x:-63.7,y:-15.7},6).wait(7).to({startPosition:0},0).to({regX:2.2,scaleX:1,scaleY:1,rotation:10,x:-64,y:-0.1},3).to({scaleX:1,scaleY:1,rotation:-44.3,x:-46.8,y:14},4).to({_off:true},1).wait(109));

	// 图层 14
	this.instance_24 = new lib.元件1("synched",0);
	this.instance_24.setTransform(-22.6,-4.8,1,1,30.2,0,0,11,-5.2);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(213).to({_off:false},0).to({regX:10.9,rotation:38.7,x:-41.2,y:-4.4},3).to({rotation:30.5,x:-40.7,y:-4.8},3).to({rotation:32,x:-40.8},4).wait(25).to({startPosition:0},0).to({regY:-5.1,rotation:23.8,x:-40.6,y:-4.7},4).to({regY:-5.2,rotation:55,y:-4.9},4).to({rotation:51,x:-40.8,y:-5},6).wait(7).to({startPosition:0},0).to({regY:-5.3,rotation:-44.3,x:-38.2,y:-9.8},7).to({_off:true},1).wait(109));

	// 右手
	this.instance_25 = new lib.元件47("synched",0);
	this.instance_25.setTransform(40.3,-11.7,1,1,-33.5,0,0,-2,-2.8);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(159).to({_off:false},0).to({rotation:-40.2,x:65.7,y:-14.8},3).to({rotation:-32,x:65.8,y:-11},3).to({rotation:-33.5,y:-11.7},4).wait(87).to({startPosition:0},0).to({rotation:-14.5,x:65.9,y:-3.1},4).to({rotation:-48.5,x:64.1,y:-17.7},4).to({rotation:-41.7,x:65.1,y:-14.9},6).wait(7).to({startPosition:0},0).to({rotation:-1.3,x:63.8,y:2.9},3).to({rotation:52.3,x:45.8,y:17.4},4).to({_off:true},1).wait(101));

	// 图层 12
	this.instance_26 = new lib.元件2("synched",0);
	this.instance_26.setTransform(14.5,-8.1,1,1,-33.5,0,0,-10.7,-5.2);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(159).to({_off:false},0).to({regX:-10.6,regY:-5.3,rotation:-40.2,x:40.5,y:-8.3},3).to({regX:-10.7,regY:-5.2,rotation:-32,x:39.9,y:-8.1},3).to({rotation:-33.5,x:40},4).wait(87).to({startPosition:0},0).to({regY:-5.3,rotation:-14.5,x:40.3},4).to({rotation:-48.5,x:40,y:-7.6},4).to({regX:-10.6,rotation:-41.7,x:40.1,y:-7.7},6).wait(7).to({startPosition:0},0).to({rotation:52.3,x:40.3,y:-8.1},7).to({_off:true},1).wait(101));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.元件15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{aa:0});

	// timeline functions:
	this.frame_0 = function() {
		/* 在此帧处停止
		时间轴将在插入此代码的帧处停止/暂停。
		也可用于停止/暂停影片剪辑的时间轴。
		*/
		
		this.stop();
	}
	this.frame_385 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(385).call(this.frame_385).wait(1));

	// 图层 2
	this.instance = new lib.下拉();
	this.instance.setTransform(-148.5,-61);

	this.instance_1 = new lib.下拉按下();
	this.instance_1.setTransform(-147,-62.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(385));

	// 图层 1
	this.instance_2 = new lib.元件41("synched",0);
	this.instance_2.setTransform(180.5,80.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(386));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.5,-61,25,20);


// stage content:
(lib.aa_mv = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* 在此帧处停止
		时间轴将在插入此代码的帧处停止/暂停。
		也可用于停止/暂停影片剪辑的时间轴。
		*/
		
		this.stop();
		//this.D.visible = false;
		this.g_btn.visible = false;
		
		
		/* Mouse Click 事件
		单击此指定的元件实例会执行您可在其中添加自己的自定义代码的函数。
		
		说明:
		1. 在以下"// 开始您的自定义代码"行后的新行上添加您的自定义代码。
		单击此元件实例时，此代码将执行。
		*/
		
		this.aa_btn.addEventListener("click", fl_MouseClickHandler.bind(this));
		
		function fl_MouseClickHandler()
		{
			this.g_btn.visible = true;
			//this.D.visible = true;
			this.D.gotoAndPlay(2);
			//this.d.visible = false;
			//this.aa_btn.visible = false;
		
		}
		
		/* 显示对象
		显示指定的元件实例。
		
		说明:
		1. 使用此代码显示当前隐藏的对象。
		*/
		
		
		/* Mouse Click 事件
		单击此指定的元件实例会执行您可在其中添加自己的自定义代码的函数。
		
		说明:
		1. 在以下"// 开始您的自定义代码"行后的新行上添加您的自定义代码。
		单击此元件实例时，此代码将执行。
		*/
		
		this.g_btn.addEventListener("click", fl_MouseClickHandler_2.bind(this));
		
		function fl_MouseClickHandler_2()
		{
			
			//this.D.visible = false;
			this.g_btn.visible = false;
			this.D.gotoAndStop("aa");
			//this.d.visible = true;
			this.aa_btn.visible = true;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.aa_btn = new lib.kk_55363();
	this.aa_btn.setTransform(62.3,29.9,1,1,0,0,0,143.9,107.5);
	new cjs.ButtonHelper(this.aa_btn, 0, 1, 2, false, new lib.kk_55363(), 3);

	this.timeline.addTween(cjs.Tween.get(this.aa_btn).wait(1));

	// 图层 3
	this.D = new lib.元件15();
	this.D.setTransform(366.8,118.6,1,1,0,0,0,90.2,40.4);

	this.g_btn = new lib.kk_34905();
	this.g_btn.setTransform(842,28.6,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.g_btn, 0, 1, 2, false, new lib.kk_34905(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.g_btn},{t:this.D}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(433,142.6,855,146.4);

})(aa_mv = aa_mv||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var aa_mv, images, createjs, ss;