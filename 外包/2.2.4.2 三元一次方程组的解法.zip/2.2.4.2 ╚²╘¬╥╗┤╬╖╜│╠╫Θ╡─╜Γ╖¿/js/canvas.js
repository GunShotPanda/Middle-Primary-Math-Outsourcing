function change_1(){
	var text_1=document.getElementsByClassName('text_1')[0];
	if($(".text_1").hasClass("change")){
		$(".text_1").removeClass("change");
		text_1.style.opacity="0";
	}
	else{
		$('.text_1').addClass('change');
		text_1.style.opacity="1";
	}
}
function change_2(){
	var text_1=document.getElementsByClassName('img_1')[0];
	var text_2=document.getElementsByClassName('img_2')[0];
	if($(".img_1").hasClass("change")){
		$(".img_1").removeClass("change");
		text_1.style.opacity="0";
		text_2.style.opacity="0";
		if($('img_2').hasClass("change")){
			$('img_2').removeClass("change");
		}
	}
	else{
		$('.img_1').addClass('change');
		text_1.style.opacity="1";
	}
}
function change_3(){
	var text_1=document.getElementsByClassName('img_2')[0];
	if($(".img_2").hasClass("change")){
		$(".img_2").removeClass("change");
		text_1.style.opacity="0";
	}
	else{
		if($('.img_1').hasClass("change")){
			$('.img_2').addClass('change');
			text_1.style.opacity="1";
		}
		
	}
}


var canvas_1=document.getElementById('canvas_1');
var canvas_2=document.getElementById('canvas_2');

var context_1=canvas_1.getContext("2d");
var context_2=canvas_2.getContext("2d");

context_1.fillStyle="red";
context_1.strokeStyle="#000000";

context_1.lineWidth=5;
context_1.moveTo(150,10);
context_1.lineTo(150,130);
context_1.lineTo(135,115);

context_1.moveTo(150,130);
context_1.lineTo(165,115);
context_1.stroke();

context_1.font="35px   	SimSun";
context_1.fillText("消元",160,75);


context_2.fillStyle="red";
context_2.strokeStyle="#000000";

context_2.lineWidth=5;
context_2.moveTo(150,10);
context_2.lineTo(150,130);
context_2.lineTo(135,115);

context_2.moveTo(150,130);
context_2.lineTo(165,115);
context_2.stroke();

context_2.font="35px   	SimSun";
context_2.fillText("消元",160,75);




